from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon
import os.path
from . import TIF_taker

class AreaLadybugPlugin:
    """Main plugin class for the Area Ladybug plugin"""

    def __init__(self, iface):
        """Constructor
        
        :param iface: An interface instance that will be passed to this class
            which provides the hook by which you can manipulate the QGIS
            application at run time.
        :type iface: QgsInterface
        """
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.actions = []

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI"""
        icon_path = os.path.join(self.plugin_dir, "icon.png")
        action = QAction(
            QIcon(icon_path),
            "Area Ladybug", 
            self.iface.mainWindow()
        )
        action.triggered.connect(self.run)
        action.setEnabled(True)
        
        # Add to QGIS toolbar and menu
        self.iface.addToolBarIcon(action)
        self.iface.addPluginToMenu("&Area Ladybug", action)
        self.actions.append(action)

    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI"""
        for action in self.actions:
            self.iface.removePluginMenu("&Area Ladybug", action)
            self.iface.removeToolBarIcon(action)

    def run(self):
        """Run method that performs all the real work"""
        TIF_taker.main()

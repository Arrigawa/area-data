import os
from qgis.PyQt.QtWidgets import QAction, QMenu
from qgis.PyQt.QtGui import QIcon
from qgis.core import QgsApplication
from .TIF_taker import main as tif_taker_main
from .cordinate import main as ladybug_main

class AreaPlugin:
    """QGIS Plugin for Area Analysis with TIF files"""
    
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.actions = []
        self.menu = 'Area Plugin'

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""
        
        # Create action for TIF Taker with custom text label
        tif_action = QAction(
            'area.TIF',  # Display "area.TIF" as the button text
            self.iface.mainWindow()
        )
        tif_action.triggered.connect(self.run_tif_taker)
        tif_action.setStatusTip('Load TIF files from a folder')
        
        # Create action for Ladybug with custom text label
        ladybug_action = QAction(
            'Ladybug',  # Display "Ladybug" as the button text
            self.iface.mainWindow()
        )
        ladybug_action.triggered.connect(self.run_ladybug)
        ladybug_action.setStatusTip('Load Ladybug coordinates from a text file')
        
        # Add to QGIS interface
        self.iface.addPluginToRasterMenu(self.menu, tif_action)
        self.iface.addPluginToVectorMenu(self.menu, ladybug_action)
        self.iface.addToolBarIcon(tif_action)
        self.iface.addToolBarIcon(ladybug_action)
        self.actions.append(tif_action)
        self.actions.append(ladybug_action)

    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu(self.menu, action)
            self.iface.removeToolBarIcon(action)

    def run_tif_taker(self):
        """Run TIF Taker when tool is triggered"""
        tif_taker_main()
        
    def run_ladybug(self):
        """Run Ladybug coordinates loader when tool is triggered"""
        ladybug_main()

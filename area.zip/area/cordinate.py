import os
import re
from qgis.core import (
    QgsProject, QgsVectorLayer, QgsCoordinateReferenceSystem,
    QgsMarkerSymbol, QgsPalLayerSettings, QgsTextFormat,
    QgsVectorLayerSimpleLabeling, QgsDataProvider
)
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtGui import QColor, QFont
from qgis.utils import iface
from qgis.PyQt.QtWidgets import QMessageBox

def is_valid_ladybug_format(file_path):
    """
    Check if the file has the correct ladybug format for coordinates
    Accept various formats that might be valid
    """
    try:
        with open(file_path, 'r') as f:
            lines = [line.strip() for line in f.readlines()[:5] if line.strip()]
            if not lines:
                return False
                
            # Check if the file has comma-separated values with numbers
            for line in lines:
                parts = line.split(',')
                # Need at least 3 parts (id, x, y)
                if len(parts) < 3:
                    continue
                
                # Try to parse the second and third parts as floats (X and Y coordinates)
                try:
                    x = float(parts[1])
                    y = float(parts[2])
                    # If we can parse a line with valid coordinates, consider the file valid
                    return True
                except ValueError:
                    continue
                    
            return False
    except Exception as e:
        print(f"Error reading file {file_path}: {str(e)}")
        return False

def find_ladybug_files(folder_path):
    """
    Scan folder recursively for ladybug.txt or any txt files with ladybug coordinate format
    """
    ladybug_files = []
    
    # First priority: look for files named exactly ladybug.txt
    for root, _, files in os.walk(folder_path):
        for file in files:
            if file.lower() == 'ladybug.txt':
                file_path = os.path.join(root, file)
                # Verify it has the correct format
                if is_valid_ladybug_format(file_path):
                    ladybug_files.append(file_path)
                    print(f"Found ladybug.txt: {file_path}")
                    return [file_path]  # Return immediately if ladybug.txt is found
    
    # Second priority: look for files with valid ladybug format
    for root, _, files in os.walk(folder_path):
        for file in files:
            if file.lower().endswith('.txt') and file.lower() != 'ladybug.txt':
                file_path = os.path.join(root, file)
                if is_valid_ladybug_format(file_path):
                    ladybug_files.append(file_path)
                    print(f"Found valid ladybug format file: {file_path}")
    
    return ladybug_files

def load_ladybug_file_automatically(file_path):
    """
    Automatically load ladybug file from text file using direct method.
    """
    try:
        # Debug: Print the file path and content
        print(f"Attempting to load ladybug file from: {file_path}")
        
        try:
            with open(file_path, 'r') as f:
                lines = f.readlines()
                print(f"File has {len(lines)} lines")
                print(f"First few lines: {lines[:3]}")
                
                # Check for common format issues
                if len(lines) > 0:
                    first_line = lines[0].strip()
                    parts = first_line.split(',')
                    print(f"First line parts: {parts}")
                    if len(parts) >= 3:
                        print(f"Potential X coordinate: {parts[1]}")
                        print(f"Potential Y coordinate: {parts[2]}")
        except Exception as e:
            print(f"Could not read file for debugging: {str(e)}")
            
        # Create a fixed temporary copy of the file with correct format if needed
        import tempfile
        import shutil
        
        temp_file_path = None
        try:
            with open(file_path, 'r') as f:
                content = f.read()
                
            # Create a temporary file
            fd, temp_file_path = tempfile.mkstemp(suffix='.txt')
            os.close(fd)
            
            with open(temp_file_path, 'w') as f:
                # Write the content as is
                f.write(content)
                
            print(f"Created temporary file: {temp_file_path}")
        except Exception as e:
            print(f"Failed to create temporary file: {str(e)}")
            temp_file_path = file_path  # Fallback to original file
        
        # Try loading with different approaches
        layer_name = "ladybug"
        ladybug_layer = None
        
        # Approach 1: Standard delimited text
        uri = (f"file:///{temp_file_path}"
               f"?delimiter=,"
               f"&xField=1&yField=2"
               f"&crs=EPSG:32632"
               f"&detectTypes=yes")
        
        ladybug_layer = QgsVectorLayer(uri, layer_name, "delimitedtext")
        
        if not ladybug_layer.isValid():
            print("Approach 1 failed, trying approach 2...")
            
            # Approach 2: Try with explicit field definitions
            uri = (f"file:///{temp_file_path}"
                  f"?delimiter=,"
                  f"&xField=1&yField=2"
                  f"&crs=EPSG:32632"
                  f"&useHeader=no"
                  f"&skipEmptyFields=yes"
                  f"&trimFields=yes")
            
            ladybug_layer = QgsVectorLayer(uri, layer_name, "delimitedtext")
            
            if not ladybug_layer.isValid():
                print("Approach 2 failed, trying approach 3...")
                
                # Approach 3: Try processing the file first
                try:
                    # Create a temporary CSV file with headers
                    processed_file = tempfile.mktemp(suffix='.csv')
                    with open(file_path, 'r') as fin, open(processed_file, 'w') as fout:
                        fout.write("id,x,y\n")  # Add header
                        for line in fin:
                            fout.write(line)  # Copy content
                            
                    uri = (f"file:///{processed_file}"
                          f"?delimiter=,"
                          f"&xField=x&yField=y"
                          f"&crs=EPSG:32632")
                    
                    ladybug_layer = QgsVectorLayer(uri, layer_name, "delimitedtext")
                except Exception as e:
                    print(f"Approach 3 failed: {str(e)}")
        
        if not ladybug_layer or not ladybug_layer.isValid():
            QMessageBox.warning(
                iface.mainWindow(), 
                "Error", 
                f"Failed to load ladybug.txt file. Please check the file format."
            )
            return None
        
        # Add to project
        QgsProject.instance().addMapLayer(ladybug_layer)
        
        # Style and configure the layer
        symbol = QgsMarkerSymbol.createSimple({
            'name': 'circle',
            'color': '#FF00FF',  # Magenta
            'size': '4.0',
            'outline_style': 'solid',
            'outline_color': '#000000',
            'outline_width': '0.4'
        })
        ladybug_layer.renderer().setSymbol(symbol)
        
        fields = [field.name() for field in ladybug_layer.fields()]
        print(f"Layer fields: {fields}")
        
        id_field = None
        for field in fields:
            if field.lower() in ['o_1', 'id', 'field_1']:
                id_field = field
                break
                
        if not id_field and fields:
            id_field = fields[0]
            
        if id_field:
            try:
                ladybug_layer.setSubsetString(f"\"{id_field}\" = '0_1'")
            except Exception as e:
                print(f"Could not set filter: {str(e)}")
                
            try:
                label_settings = QgsPalLayerSettings()
                label_settings.fieldName = id_field
                label_settings.enabled = True
                
                text_format = QgsTextFormat()
                font = QFont("Open Sans")
                font.setPointSize(10)
                text_format.setFont(font)
                text_format.setColor(QColor("black"))
                label_settings.setFormat(text_format)
                
                labeling = QgsVectorLayerSimpleLabeling(label_settings)
                ladybug_layer.setLabelsEnabled(True)
                ladybug_layer.setLabeling(labeling)
            except Exception as e:
                print(f"Could not set labels: {str(e)}")
        
        root = QgsProject.instance().layerTreeRoot()
        ladybug_node = root.findLayer(ladybug_layer.id())
        if ladybug_node:
            clone = ladybug_node.clone()
            root.insertChildNode(0, clone)
            parent = ladybug_node.parent()
            parent.removeChildNode(ladybug_node)
            
            new_node = root.findLayer(ladybug_layer.id())
            if new_node:
                new_node.setItemVisibilityChecked(True)
        
        ladybug_layer.triggerRepaint()
        if ladybug_layer.featureCount() > 0:
            iface.mapCanvas().setExtent(ladybug_layer.extent())
        iface.mapCanvas().refresh()
        
        return ladybug_layer
        
    except Exception as e:
        import traceback
        print(f"Error loading ladybug file: {str(e)}")
        print(traceback.format_exc())
        QMessageBox.warning(
            iface.mainWindow(),
            "Error",
            f"Error processing ladybug.txt: {str(e)}"
        )
        return None

def main():
    """
    Main function that automatically processes the ladybug file 
    """
    from qgis.PyQt.QtWidgets import QFileDialog, QInputDialog, QMessageBox
    
    folder_path = QFileDialog.getExistingDirectory(
        iface.mainWindow(),
        "Select folder containing ladybug.txt",
        os.path.join(os.path.expanduser("~"), "Documents")
    )
    
    if not folder_path:
        print("No folder selected. Cancelling operation.")
        return
    
    ladybug_files = find_ladybug_files(folder_path)
    
    if not ladybug_files:
        QMessageBox.warning(
            iface.mainWindow(),
            "No Ladybug Files Found",
            f"No ladybug.txt or valid coordinate files found in {folder_path} or its subfolders."
        )
        return
    
    ladybug_file = ladybug_files[0]
    if len(ladybug_files) > 1:
        file_names = [os.path.basename(f) for f in ladybug_files]
        selected, ok = QInputDialog.getItem(
            iface.mainWindow(),
            "Select Ladybug File",
            "Multiple ladybug files found. Select one:",
            file_names,
            0,
            False
        )
        if ok and selected:
            index = file_names.index(selected)
            ladybug_file = ladybug_files[index]
        else:
            print("No file selected.")
            return
    
    ladybug_layer = load_ladybug_file_automatically(ladybug_file)
    
    if ladybug_layer:
        QMessageBox.information(
            iface.mainWindow(),
            "Success",
            f"Ladybug coordinates from {os.path.basename(ladybug_file)} loaded successfully with:\n"
            "- Styling applied\n"
            "- Filter configured\n"
            "- Labels set up"
        )

if __name__ == "__main__":
    main()

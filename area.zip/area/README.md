# Area Ladybug Plugin

This QGIS plugin automatically loads raster TIF files and ladybug coordinates from txt files and displays them on the map.

## Installation

1. Copy the entire `area` folder to your QGIS plugins directory:
   `C:\Users\<username>\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\`

2. Open QGIS and go to Plugins > Manage and Install Plugins
   
3. Enable the "area" plugin in the Installed tab

## Usage

1. Prepare your data:
   - A TIF file (raster layer)
   - A text file with ladybug coordinates in format: x,y,id (comma-separated)
   
2. Default file paths (modify in auto_area.py if needed):
   - TIF file: "c:/Users/hmq/Downloads/python/qgis/area/area.TIF"
   - Coordinates: "c:/Users/hmq/Downloads/python/qgis/area/ladybug.txt"

3. Start the plugin:
   - From the QGIS toolbar or menu (if you implemented the UI)
   - Or run in the Python Console:
     ```python
     import sys
     sys.path.append("c:/Users/hmq/AppData/Roaming/QGIS/QGIS3/profiles/default/python/plugins/area")
     import auto_area
     auto_area.main()
     ```

## Testing

### Method 1: Using the test function

Run this code in the QGIS Python Console:

```python
import sys
sys.path.append("c:/Users/hmq/AppData/Roaming/QGIS/QGIS3/profiles/default/python/plugins/area")
import auto_area
auto_area.main(test_mode=True)
```

This will create temporary test data and run the plugin functions on it.

### Method 2: Testing with your own data

1. Prepare a test TIF file and a coordinates text file
2. Run this code in the QGIS Python Console:

```python
import sys
sys.path.append("c:/Users/hmq/AppData/Roaming/QGIS/QGIS3/profiles/default/python/plugins/area")
import auto_area

# Test with specific paths
raster_layer = auto_area.load_raster_layer("path/to/your/test.tif")
ladybug_layer = auto_area.load_ladybug_coordinates("path/to/your/coordinates.txt")

if ladybug_layer:
    auto_area.set_provider_filter(ladybug_layer, "\"o_1\" = '0_1'")
    auto_area.configure_labels(ladybug_layer)
    print("Test successful")
```

## Troubleshooting

- If the plugin doesn't appear in QGIS, check for any error messages in the Python Console
- Make sure all required files are in the plugin directory
- Verify that the TIF file is a valid raster and the coordinates file is properly formatted
- If using relative paths, make sure they're correct relative to your QGIS project file
